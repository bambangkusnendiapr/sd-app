<?php $__env->startSection('title', 'Rapor'); ?>

<?php $__env->startSection('sidebar', 'sidebar-collapse'); ?>

<?php $__env->startSection('rapor', 'active'); ?>

<div>

  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Data Rapor</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Admin</a></li>
            <li class="breadcrumb-item active">Data Rapor</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  
  <!-- Main content -->
  <section class="content">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <!-- Default box -->
          <div class="card">
            <div class="card-header">
              <button wire:click.prevent="addNew" type="button" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Data</button>
  
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <select wire:model="paginate" class="form-control form-control-sm">
                            <option value="10">10 data per halaman</option>
                            <option value="15">15 data per halaman</option>
                            <option value="20">20 data per halaman</option>
                            <option value="30">30 data per halaman</option>
                            <option value="50">50 data per halaman</option>
                        </select>
                    </div>
                </div>
              </div>
  
              <div class="table-responsive-sm">
                <table class="table table-sm table-striped mt-1">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>Semester</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $raporHeader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td><?php echo e($raporHeader->firstItem() + $key); ?></td>
                            <td><?php echo e($data->kelas); ?></td>
                            <td><?php echo e($data->jurusan->nama); ?></td>
                            <td><?php echo e($data->semester->nama); ?> - <?php echo e($data->semester->tahun); ?></td>
                            <td>
                              <?php if($data->status == 'DRAFT'): ?>
                              <button wire:click.prevent="terbit(<?php echo e($data->id); ?>)" class="btn btn-warning" title="Terbitkan!"><i class="far fa-sticky-note"></i> <?php echo e($data->status); ?></button>
                              <?php else: ?>
                              <button class="btn btn-success" style="pointer-events: none;"><i class="fas fa-check"></i> <?php echo e($data->status); ?></button>
                              <?php endif; ?>
                            </td>
                            <td>
                              <?php if($data->status == 'DRAFT'): ?>
                              <div class="btn-group" role="group" aria-label="Basic example">
                                <button wire:click.prevent="edit(<?php echo e($data->id); ?>)" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                <button wire:click.prevent="delete(<?php echo e($data->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                              </div>
                              <?php endif; ?>
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center font-italic text-danger"><h5>-- Data Tidak Ditemukan --</h5></td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer">
              <div class="d-flex justify-content-center">
               <?php echo e($raporHeader->onEachSide(1)->links()); ?>

              </div>
            </div>
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header">Lihat Rapor Siswa</div>
            <div class="card-body">
              <div class="row">

                <div class="col-md-4">
                  <div class="form-group">
                    <select wire:model="pilihKelas" class="form-control">
                      <?php if($pilihRaporId === null): ?>
                      <option value="">Pilih Kelas</option>
                      <?php endif; ?>
                      <option value="X">X</option>
                      <option value="XI">XI</option>
                      <option value="XII">XII</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <select wire:model="pilihJurusan" class="form-control">
                      <?php if($pilihRaporId === null): ?>
                      <option value="">Pilih Jurusan</option>
                      <?php endif; ?>
                      <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <select wire:model="pilihSemester" class="form-control">
                      <?php if($pilihRaporId === null): ?>
                      <option value="">Pilih Semester</option>
                      <?php endif; ?>
                      <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

              </div>
              <div class="row justify-content-center">
                <div class="col-8">
                  <div class="form-group">
                    <select wire:model="pilihRaporId" class="form-control">
                      <option value="">Pilih Siswa</option>
                      <?php if($pilihRapor != null): ?>
                        <?php $__currentLoopData = $pilihRapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($data->id); ?>"><?php echo e($data->siswa->user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <?php if($pilihRaporId != null && $pilihRapor != null): ?>
            <div class="card">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Mata Pelajaran</th>
                        <th scope="col">KB</th>
                        <th scope="col">Pengetahuan</th>
                        <th scope="col">Keterampilan</th>
                        <th scope="col">Nilai Akhir</th>
                        <th scope="col">Predikat</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kel->id == 3): ?>
                          <tr>
                            <th scope="row" colspan="7">C. Muatan Peminatan Kejuruan</th>
                          </tr>
                        <?php endif; ?>
                        <tr>
                          <th scope="row" colspan="7"><?php echo e($kel->nama); ?></th>
                        </tr>
                        <?php $__currentLoopData = $pelajaran->where('kelompok_id', $kel->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pel->nama); ?></td>
                            <?php $__currentLoopData = $nilai->where('rapor_id', $pilihRaporId)->where('pelajaran_id', $pel->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($nl->kb); ?></td>
                            <td><?php echo e($nl->pengetahuan_nilai); ?></td>
                            <td><?php echo e($nl->keterampilan_nilai); ?></td>
                            <td><?php echo e(($nl->pengetahuan_nilai * 0.3) + ($nl->keterampilan_nilai * 0.7)); ?></td>
                            <?php $nilaiAkhir = ($nl->pengetahuan_nilai * 0.3) + ($nl->keterampilan_nilai * 0.7); $predikat = null; ?>
                            <td>
                              <?php if($nilaiAkhir >= 90): ?> 
                                A
                              <?php endif; ?>
                              <?php if($nilaiAkhir >= 79 && $nilaiAkhir <= 89): ?> 
                                B
                              <?php endif; ?>
                              <?php if($nilaiAkhir >= 68 && $nilaiAkhir <= 78): ?> 
                                C
                              <?php endif; ?>
                              <?php if($nilaiAkhir >= 57 && $nilaiAkhir <= 67): ?> 
                                D
                              <?php endif; ?>
                              <?php if($nilaiAkhir <= 56): ?> 
                                E
                              <?php endif; ?>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>              
              </div>
            </div>

            <div class="card">
              <div class="card-body">
                <p><strong>B. Catatan Akademik</strong></p>
                <div class="table-responsive">
                  <table class="table table-bordered">
                    <tr>
                      <td colspan="3">
                        <form wire:submit.prevent="updateCatatanAkademik">
                          <div class="form-group">
                            <textarea wire:model.defer="state.catatanAkademik" class="form-control <?php $__errorArgs = ['catatanAkademik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="Catatan Akademik"></textarea>
                            <?php $__errorArgs = ['catatanAkademik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <button type="submit" class="btn btn-warning">Update Catatan Akademik</button>
                        </form>
                      </td>
                    </tr>
                    <tr>
                      <td width="30%">Jumlah Mapel yang diremedial</td>
                      <td colspan="2">1</td>
                    </tr>
                    <tr>
                      <td>Peringkat</td>
                      <td>Jumlah: <strong>10</strong></td>
                      <td>Rangking: <strong>2</strong></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
                <p><strong>C. Ekstrakurikuler</strong> <button wire:click.prevent="addEskul" type="submit" class="btn btn-warning">Tambah Ekstrakurikuler</button></p>
                <div class="table-responsive">
                  <table class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>No.</th>
                        <th>Kegiatan Ekstrakurikuler</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $raporEskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($eskul->ekstrakurikuler->nama); ?></td>
                        <td><?php echo e($eskul->ket); ?></td>
                        <td><button wire:click.prevent="deleteEskul(<?php echo e($eskul->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                      </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
                <p><strong>D. Ketidakhadiran</strong></p>
                <div class="table-responsive">
                  <form wire:submit.prevent="updateKetidakhadiran">
                    <table class="table table-bordered">
                      <tr>
                        <td width="30%">Sakit</td>
                        <td>
                          <input wire:model.defer="state.sakit" type="number" required class="form-control <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                          <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                      </tr>
                      <tr>
                        <td>Izin</td>
                        <td>
                          <input wire:model.defer="state.izin" type="number" required class="form-control <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                          <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                      </tr>
                      <tr>
                        <td>Tanpa Keterangan</td>
                        <td>
                          <input wire:model.defer="state.alpa" type="number" required class="form-control <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                          <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                      </tr>
                      <tr>
                        <td class="text-center" colspan="2"><button type="submit" class="btn btn-warning">Update Data Ketidakhadiran</button></td>
                      </tr>
                    </table>
                  </form>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
                <p><strong>E. Deskripsi Perkembangan Karakter</strong> <button wire:click.prevent="addRaporKarakter" type="submit" class="btn btn-warning">Tambah Perkembangan Karakter</button></p>
                <div class="table-responsive">
                  <table class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>No.</th>
                        <th>Karakter yang dibangun</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $raporKarakter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($karak->karakter->nama); ?></td>
                        <td><?php echo e($karak->ket); ?></td>
                        <td><button wire:click.prevent="deleteRaporKarakter(<?php echo e($karak->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                      </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
                <p><strong>F. Catatan Perkembangan Karakter</strong></p>
                <form wire:submit.prevent="updateCatatanKarakter">
                  <textarea wire:model.defer="state.catatanKarakter" class="form-control <?php $__errorArgs = ['catatanKarakter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="Catatan Perkembangan Karakter"></textarea>
                  <?php $__errorArgs = ['catatanKarakter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                      <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <br>
                  <button type="submit" class="btn btn-warning">Update Catatan Perkembangan Karakter</button>
                </form>
              </div>
            </div>
          <?php endif; ?>

        </div>
      </div>
    </div>
  </section>
  
  <div class="modal fade" id="form" wire:ignore.self>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header <?php echo e($form == 'tambah' ? 'bg-primary':'bg-warning'); ?>">
          <h4 class="modal-title"><?php echo e($form == 'tambah' ? 'Tambah':'Edit'); ?> Rapor</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php if($form == 'tambah'): ?>
        <form wire:submit.prevent="createData">
        <?php else: ?>
        <form wire:submit.prevent="updateData">
        <?php endif; ?>
          <div class="modal-body">
            <?php if($dataDuplikat != null): ?>
              <h5 class="text-danger">Data Tersebut sudah ada</h5>
            <?php endif; ?>

            <div class="form-group">
                <label for="kelas">Kelas</label>
                <select wire:model.defer="state.kelas" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="kelas">
                  <option value="">Pilih Kelas</option>
                  <option value="X">X</option>
                  <option value="XI">XI</option>
                  <option value="XII">XII</option>
                </select>
                <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="jurusan">Jurusan</label>
                <select wire:model.defer="state.jurusan" class="form-control <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="jurusan">
                  <option value="">Pilih Jurusan</option>
                  <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="semester">Semester</label>
                <select wire:model.defer="state.semester" class="form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="semester">
                  <option value="">Pilih Semester</option>
                  <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <?php if($form == 'tambah'): ?>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <?php else: ?>
            <button type="submit" class="btn btn-warning">Edit</button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

  <div class="modal fade" id="form-delete">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title">Konfirmasi Hapus Rapor</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body bg-danger">
            <h5>Yakin ingin hapus data ?</h5>
        </div>
        <div class="modal-footer justify-content-between bg-danger">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            <button wire:click.prevent="deleteData" type="button" class="btn btn-light">Lanjut Hapus</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <div class="modal fade" id="modal-terbit">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-warning">
          <h4 class="modal-title">Konfirmasi Penerbitan Rapor</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <h5>Yakin dengan penerbitan rapor ini ?</h5>
            <p>Rapor yang sudah terbit akan dikunci, tidak bisa diedit dan dihapus</p>
        </div>
        <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            <button wire:click.prevent="terbitData" type="button" class="btn btn-warning">Terbitkan</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <div class="modal fade" id="eskul-form" wire:ignore.self>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header <?php echo e($form == 'tambah' ? 'bg-primary':'bg-warning'); ?>">
          <h4 class="modal-title"><?php echo e($form == 'tambah' ? 'Tambah':'Edit'); ?> Eskul Siswa</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php if($form == 'tambah'): ?>
        <form wire:submit.prevent="createEskul">
        <?php else: ?>
        <form wire:submit.prevent="updateEskul">
        <?php endif; ?>
          <div class="modal-body">

            <div class="form-group">
                <label for="ekstrakurikuler">Ekstrakurikuler</label>
                <select wire:model.defer="state.ekstrakurikuler" class="form-control <?php $__errorArgs = ['ekstrakurikuler'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="ekstrakurikuler">
                  <option value="">Pilih Ekstrakurikuler</option>
                  <?php $__currentLoopData = $ekstrakurikuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['ekstrakurikuler'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="keterangan">Keterangan</label>
                <textarea wire:model.defer="state.keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="keterangan" placeholder="Keterangan"></textarea>
                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <?php if($form == 'tambah'): ?>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <?php else: ?>
            <button type="submit" class="btn btn-warning">Edit</button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

  <div class="modal fade" id="rapor-karakter-form" wire:ignore.self>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header <?php echo e($form == 'tambah' ? 'bg-primary':'bg-warning'); ?>">
          <h4 class="modal-title"><?php echo e($form == 'tambah' ? 'Tambah':'Edit'); ?> Karakter Siswa</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php if($form == 'tambah'): ?>
        <form wire:submit.prevent="createRaporKarakter">
        <?php else: ?>
        <form wire:submit.prevent="updateRaporKarakter">
        <?php endif; ?>
          <div class="modal-body">

            <div class="form-group">
                <label for="karakter">Karakter</label>
                <select wire:model.defer="state.karakter" class="form-control <?php $__errorArgs = ['karakter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="karakter">
                  <option value="">Pilih Karakter</option>
                  <?php $__currentLoopData = $karakter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['karakter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="keterangan">Keterangan</label>
                <textarea wire:model.defer="state.keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="keterangan" placeholder="Keterangan"></textarea>
                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <?php if($form == 'tambah'): ?>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <?php else: ?>
            <button type="submit" class="btn btn-warning">Edit</button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

</div>

<?php $__env->startPush('style'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- Sweet alert real rashid -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
  $(function () {

    window.addEventListener('show-form', event => {
        $('#form').modal('show');
    });

    window.addEventListener('hide-form', event => {
        $('#form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('show-form-delete', event => {
        $('#form-delete').modal('show');
    });

    window.addEventListener('hide-form-delete', event => {
        $('#form-delete').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Dihapus",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('show-terbit', event => {
        $('#modal-terbit').modal('show');
    });

    window.addEventListener('hide-terbit', event => {
        $('#modal-terbit').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Rapor Berhasil Diterbitkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('catatan-akademik', event => {

        Swal.fire({
            "title":"Sukses!",
            "text":"Catatan Akademik Berhasil Diupdate",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('eskul-show-form', event => {
        $('#eskul-form').modal('show');
    });

    window.addEventListener('hide-eskul-form', event => {
        $('#eskul-form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('ketidakhadiran', event => {

      Swal.fire({
          "title":"Sukses!",
          "text":"Ketidakhadiran Berhasil Diupdate",
          "position":"middle-center",
          "timer":2000,
          "width":"32rem",
          "heightAuto":true,
          "padding":"1.25rem",
          "showConfirmButton":false,
          "showCloseButton":false,
          "icon":"success"
      });

    });

    window.addEventListener('rapor-karakter-show-form', event => {
        $('#rapor-karakter-form').modal('show');
    });

    window.addEventListener('hide-rapor-karakter-form', event => {
        $('#rapor-karakter-form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('catatan-karakter', event => {

      Swal.fire({
          "title":"Sukses!",
          "text":"Catatan Perkembangan Karakter Berhasil Diupdate",
          "position":"middle-center",
          "timer":2000,
          "width":"32rem",
          "heightAuto":true,
          "padding":"1.25rem",
          "showConfirmButton":false,
          "showCloseButton":false,
          "icon":"success"
      });

    });

    window.addEventListener('error-form', event => {
        $('#form').modal('show');
    });

  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

  })
  
</script>

<?php $__env->stopPush(); ?><?php /**PATH /home/u1686239/public_html/demorapor/resources/views/livewire/rapor-data.blade.php ENDPATH**/ ?>