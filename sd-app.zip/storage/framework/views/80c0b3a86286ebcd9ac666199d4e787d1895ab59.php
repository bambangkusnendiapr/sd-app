<?php $__env->startSection('title', 'Portofolio'); ?>

<?php $__env->startSection('portofolio', 'active'); ?>

<div>

  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Portofolio</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Admin</a></li>
            <li class="breadcrumb-item active">Portofolio</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  
  <!-- Main content -->
  <section class="content">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <?php if (app('laratrust')->hasRole('developer|admin')) : ?>
          <!-- Default box -->
          <div class="card card-outline card-primary">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <select wire:model="siswaId" class="form-control" required>
                      <option value="Semua">Pilih Siswa</option>
                      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
          <?php endif; // app('laratrust')->hasRole ?>

          <div class="card card-outline card-primary">
            <div class="card-body text-center">
              <h2>Portofolio Peserta Didik</h2>
              <h3>SD Persis Asy-Syuhada</h3>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header bg-primary">
              <h3 class="card-title">Identitas Peserta Didik</h3>
            </div>
            <?php if($siswa != 'kosong'): ?>
            <div class="card-body text-center">
              <div class="row">
                <div class="col-md-3">
                  <?php if($gambar): ?>
                  <img src="<?php echo e(asset('images/siswa/'.$gambar)); ?>" alt="Foto Siswa" class="img img-fluid" height="10px">
                  <?php else: ?>
                  <img src="<?php echo e(asset('images/user.jpg')); ?>" alt="Foto Siswa" class="img img-fluid" height="10px">
                  <?php endif; ?>
                </div>
                <div class="col-md-9">
                <div class="table-responsive">
                  <table class="table table-striped table-sm">
                    <tr class="text-left">
                      <td width="35%">Nama Peserta Didik</td>
                      <td width="5%">:</td>
                      <td><?php echo e($nama); ?></td>
                    </tr>
                    <tr class="text-left">
                      <td width="35%">No Induk</td>
                      <td width="5%">:</td>
                      <td><?php echo e($nis); ?></td>
                    </tr>
                    <tr class="text-left">
                      <td width="35%">Kelas</td>
                      <td width="5%">:</td>
                      <td><?php echo e($kelas); ?> - <?php echo e($kelasTipe); ?></td>
                    </tr>
                    <tr class="text-left">
                      <td width="35%">Tempat, Tanggal Lahir</td>
                      <td width="5%">:</td>
                      <td><?php echo e($tempatLahir); ?>, <?php echo e($tglLahir); ?></td>
                    </tr>
                    <tr class="text-left">
                      <td width="35%">Jenis Kelamin</td>
                      <td width="5%">:</td>
                      <td><?php echo e($jk); ?></td>
                    </tr>
                    <tr class="text-left">
                      <td width="35%">Alamat</td>
                      <td width="5%">:</td>
                      <td><?php echo e($alamat); ?></td>
                    </tr>
                  </table>
                </div>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header bg-primary">
              <h3 class="card-title">Profil Psikologi</h3>
            </div>
            <?php if($siswa != 'kosong'): ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-sm">
                  <tr class="text-center">
                    <th>Tanggal</th>
                    <th>IQ</th>
                    <th>Kemandirian</th>
                    <th>Kemampuan Bekerja</th>
                    <th>Penyesuaian Diri</th>
                  </tr>
                    <?php $__currentLoopData = $siswa->psychologist->where('is_deleted', false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="text-center">
                        <td><?php echo e($data->tanggal); ?></td>
                        <td><?php echo e($data->iq); ?></td>
                        <td><?php echo e($data->kemandirian); ?></td>
                        <td><?php echo e($data->kemampuan_bekerja); ?></td>
                        <td><?php echo e($data->penyesuaian_diri); ?></td>
                      </tr>                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
            <?php endif; ?>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header bg-primary">
              <h3 class="card-title">Kemampuan Peserta Didik</h3>
            </div>
            <?php if($siswa != 'kosong'): ?>
            <div class="card-body">
              <div>
                <h5><strong>1. Hafalan Surat Terakhir: </strong> <?php echo e($siswa->surat_id ? $siswa->surah->nama:''); ?> </h5>
              </div>
              <div>
                <h5><strong>2. Surat Yang Sudah Hafal</strong></h5>
                <div class="mt-n2 ml-4">
                  <?php $__currentLoopData = $siswa->surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-success"><?php echo e($surat->nama); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <div class="mt-3">
                <h5><strong>3. Tahsin</strong></h5>
                <div class="ml-4">
                  <div class="row">
                    <div class="col-12">
                      <div class="table-responsive">
                        <table class="table table-striped table-sm">
                          <tr class="text-center">
                            <th>Tanggal</th>
                            <th>Jilid</th>
                            <th>Halaman</th>
                            <th>Murajaah</th>
                            <th>Ziyadah</th>
                            <th>Nilai</th>
                          </tr>
                          <?php if($siswa != 'kosong'): ?>
                            <?php $__currentLoopData = $siswa->tahsins->where('is_deleted', false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td><?php echo e($data->tanggal); ?></td>
                                <td><?php echo e($data->jilid); ?></td>
                                <td><?php echo e($data->halaman); ?></td>
                                <td><?php echo e($data->murajaah); ?></td>
                                <td><?php echo e($data->ziyadah); ?></td>
                                <td><?php echo e($data->nilai); ?></td>
                              </tr>                  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header bg-primary">
              <h3 class="card-title">Kedisiplinan Peserta Didik</h3>
            </div>
            <?php if($siswa != 'kosong'): ?>
            <div class="card-body">
              <div class="row">
                <div class="col-12 col-sm-6 col-md-4">
                  <div class="info-box bg-secondary">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-pray"></i></span>

                    <div class="info-box-content">
                      <span class="info-box-text">Sholat Dhuha</span>
                      <span class="info-box-number">
                        <?php echo e(number_format($persenDhuha, 2, ',', '.')); ?>

                        <small>%</small>
                      </span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                  <div class="info-box bg-secondary">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-pray"></i></span>

                    <div class="info-box-content">
                      <span class="info-box-text">Sholat Fardhu</span>
                      <span class="info-box-number">
                        <?php echo e(number_format($persenFardhu, 2, ',', '.')); ?>

                        <small>%</small>
                      </span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                  <div class="info-box bg-secondary">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-utensil-spoon"></i></span>

                    <div class="info-box-content">
                      <span class="info-box-text">Shaum Sunnah</span>
                      <span class="info-box-number">
                        <?php echo e(number_format($persenShaum, 2, ',', '.')); ?>

                        <small>%</small>
                      </span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
              </div>
            </div>
            <?php endif; ?>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <?php if($siswa != 'kosong'): ?>
          <div class="card card-outline card-success">
            <div class="card-body">
              <form action="<?php echo e(route('downloadPortofolio')); ?>" method="post" target="_blank">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="siswaId" value="<?php echo e($siswa->id); ?>">
                <input type="hidden" name="persenShaum" value="<?php echo e($persenShaum); ?>">
                <input type="hidden" name="persenFardhu" value="<?php echo e($persenFardhu); ?>">
                <input type="hidden" name="persenDhuha" value="<?php echo e($persenDhuha); ?>">
                <button type="submit" class="btn btn-success"><i class="fas fa-download"></i> Download Portofolio</button>
              </form>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

</div>

<?php $__env->startPush('style'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- Sweet alert real rashid -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo e(asset('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
  $(function () {

    window.addEventListener('show-form', event => {
        $('#form').modal('show');
    });

    window.addEventListener('hide-form', event => {
        $('#form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('hide-form-edit', event => {
        $('#form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Diedit",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('show-form-delete', event => {
        $('#form-delete').modal('show');
    });

    window.addEventListener('hide-form-delete', event => {
        $('#form-delete').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Dihapus",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

  });
</script>
<script>
  $(function () {
      bsCustomFileInput.init();
  });
</script>
<script>
  $(function () {
    $('.select2').select2()
    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
  });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\sd-app\resources\views/livewire/portofolio.blade.php ENDPATH**/ ?>