<table>
    <thead>
    <tr>
        <th>tanggal</th>
        <th>siswa_id</th>
        <th>iq</th>
        <th>kemandirian</th>
        <th>kemampuan_bekerja</th>
        <th>penyesuaian_diri</th>
    </tr>
    </thead>
</table><?php /**PATH C:\laragon\www\sd-app\resources\views/admin/exports/psikolog.blade.php ENDPATH**/ ?>