<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Invoice Print</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
</head>
<body>
<div class="wrapper">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-12 text-center">
        <h2 class="page-header">
          Portofolio Peserta Didik
        </h2>
        <h3>SD Persis Asy-Syuhada</h3>
      </div>
      <!-- /.col -->
    </div>

    <hr>

    <h4>Identitas Peserta Didik</h4>
    <!-- info row -->
    <div class="row invoice-info">
      
      <div class="col-sm-9 invoice-col">
        <table width="100%">
          <tr class="text-left">
            <td width="35%">Nama Peserta Didik</td>
            <td width="5%">:</td>
            <td><?php echo e($student->nama); ?></td>
          </tr>
          <tr class="text-left">
            <td width="35%">No Induk</td>
            <td width="5%">:</td>
            <td><?php echo e($student->nis); ?></td>
          </tr>
          <tr class="text-left">
            <td width="35%">Kelas</td>
            <td width="5%">:</td>
            <td><?php echo e($student->kelas); ?> - <?php echo e($student->kls->nama); ?></td>
          </tr>
          <tr class="text-left">
            <td width="35%">Tempat, Tanggal Lahir</td>
            <td width="5%">:</td>
            <td><?php echo e($student->tempat_lahir); ?>, <?php echo e($student->tgl_lahir); ?></td>
          </tr>
          <tr class="text-left">
            <td width="35%">Jenis Kelamin</td>
            <td width="5%">:</td>
            <td><?php echo e($student->jk); ?></td>
          </tr>
          <tr class="text-left">
            <td width="35%">Alamat</td>
            <td width="5%">:</td>
            <td><?php echo e($student->alamat); ?></td>
          </tr>
        </table>
      </div>
      <!-- /.col -->

      <div class="col-sm-3 invoice-col">
        <?php if($student->gambar): ?>
        <img class="img img-fluid" src="<?php echo e(asset('images/siswa/'.$student->gambar)); ?>" alt="">
        <?php else: ?>
        <img class="img img-fluid" src="<?php echo e(asset('images/user.jpg')); ?>" alt="">
        <?php endif; ?>
      </div>
      <!-- /.col -->

    </div>
    <!-- /.row -->

    <hr>
    
    <h4>Profil Psikologi Peserta Didik</h4>
    <div class="row invoice-info">
      
      <div class="col-12 invoice-col">
        <table width="100%" class="table table-striped table-sm">
          <tr class="text-center">
            <th>Tanggal</th>
            <th>IQ</th>
            <th>Kemandirian</th>
            <th>Kemampuan Bekerja</th>
            <th>Penyesuaian Diri</th>
          </tr>
          <?php $__currentLoopData = $student->psychologist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psikolog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="text-center">
            <td><?php echo e($psikolog->tanggal); ?></td>
            <td><?php echo e($psikolog->iq); ?></td>
            <td><?php echo e($psikolog->kemandirian); ?></td>
            <td><?php echo e($psikolog->kemampuan_bekerja); ?></td>
            <td><?php echo e($psikolog->penyesuaian_diri); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <!-- /.col -->

    </div>

    <hr>

    <h4>Kemampuan Peserta Didik</h4>
    <div style="margin-top: 20px">
      <h5 style="margin-bottom: 10px">1. Hafalan Surat Terakhir: <small><?php echo e($student->surah->nama); ?></small></h5>
      <h5 style="margin-bottom: 0px">2. Surat Yang Sudah Hafal:</h5>
      <span style="margin-left: 20px">
        <?php $__currentLoopData = $student->surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span style="color: green"><?php echo e($surat->nama); ?>,</span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </span>
      <h5 style="margin-top: 10px">3. Tahsin (5 Terakhir)</h5>
      <div class="row invoice-info ml-3">
        
        <div class="col-12 invoice-col">
          <table width="100%" class="table table-striped table-sm">
            <tr class="text-center">
              <th>Tanggal</th>
              <th>Jilid</th>
              <th>Halaman</th>
              <th>Murajaah</th>
              <th>Ziyadah</th>
              <th>Nilai</th>
            </tr>
            <?php $__currentLoopData = $student->tahsins->sortByDesc('id')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahsin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
              <td><?php echo e($tahsin->tanggal); ?></td>
              <td><?php echo e($tahsin->jilid); ?></td>
              <td><?php echo e($tahsin->halaman); ?></td>
              <td><?php echo e($tahsin->murajaah); ?></td>
              <td><?php echo e($tahsin->ziyadah); ?></td>
              <td><?php echo e($tahsin->nilai); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <!-- /.col -->
  
      </div>
    </div>

    <hr>

    <h4>Kedisiplinan Peserta Didik</h4>
    <div class="row justify-content-center">
      <div class="col-md-3">
        <div class="info-box">
          <span class="info-box-icon elevation-1"><i class="fas fa-pray"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">Sholat Dhuha</span>
            <span class="info-box-number">
              <?php echo e(number_format($persenDhuha, 2, ',', '.')); ?>

              <small>%</small>
            </span>
          </div>
          <!-- /.info-box-content -->
        </div>
      </div>
      <div class="col-md-3">
        <div class="info-box">
          <span class="info-box-icon elevation-1"><i class="fas fa-pray"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">Sholat Fardhu</span>
            <span class="info-box-number">
              <?php echo e(number_format($persenFardhu, 2, ',', '.')); ?>

              <small>%</small>
            </span>
          </div>
          <!-- /.info-box-content -->
        </div>
      </div>
      <div class="col-md-3">
        <div class="info-box">
          <span class="info-box-icon elevation-1"><i class="fas fa-pray"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">Shaum Sunnah</span>
            <span class="info-box-number">
              <?php echo e(number_format($persenShaum, 2, ',', '.')); ?>

              <small>%</small>
            </span>
          </div>
          <!-- /.info-box-content -->
        </div>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
<!-- Page specific script -->
<script>
  window.addEventListener("load", window.print());
</script>
</body>
</html><?php /**PATH C:\laragon\www\sd-app\resources\views/admin/downloadPortofolio.blade.php ENDPATH**/ ?>