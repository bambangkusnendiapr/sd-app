<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="#" class="brand-link">
      <img src="<?php echo e(asset('admin/dist/img/smk wd logo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">SMK WD</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
          <img src="<?php echo e(asset('admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
          <a href="<?php echo e(route('profile')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?>

            <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge badge-success"><?php echo e($role->display_name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </a>
      </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
              with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                Dashboard
                </p>
            </a>
          </li>
          <?php if (app('laratrust')->hasRole('admin')) : ?>
          <li class="nav-item">
            <a href="<?php echo e(route('guru')); ?>" class="nav-link <?php echo $__env->yieldContent('guru'); ?>">
                <i class="nav-icon fas fa-user-tie"></i>
                <p>
                Guru
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('wali.kelas')); ?>" class="nav-link <?php echo $__env->yieldContent('waliKelas'); ?>">
                <i class="nav-icon fas fa-border-all"></i>
                <p>
                Data Wali Kelas
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('guru.pelajaran')); ?>" class="nav-link <?php echo $__env->yieldContent('guruPelajaran'); ?>">
                <i class="nav-icon fas fa-chalkboard-teacher"></i>
                <p>
                Guru & Pelajaran
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('ortu')); ?>" class="nav-link <?php echo $__env->yieldContent('ortu'); ?>">
                <i class="nav-icon fas fa-user-friends"></i>
                <p>
                Akun Orang Tua
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('siswa')); ?>" class="nav-link <?php echo $__env->yieldContent('siswa'); ?>">
                <i class="nav-icon fas fa-user-graduate"></i>
                <p>
                Siswa
                </p>
            </a>
          </li>
          <?php endif; // app('laratrust')->hasRole ?>
          <?php if (app('laratrust')->hasRole('admin|wali_kelas')) : ?>
          <li class="nav-item">
            <a href="<?php echo e(route('rapor')); ?>" class="nav-link <?php echo $__env->yieldContent('rapor'); ?>">
                <i class="nav-icon fas fa-book-open"></i>
                <p>
                Rapor
                </p>
            </a>
          </li>
          <?php endif; // app('laratrust')->hasRole ?>
          <?php if (app('laratrust')->hasRole('admin|wali_kelas|guru')) : ?>
          <li class="nav-item">
            <a href="<?php echo e(route('nilai.index')); ?>" class="nav-link <?php echo $__env->yieldContent('nilai'); ?>">
                <i class="nav-icon fas fa-file-signature"></i>
                <p>
                Penilaian
                </p>
            </a>
          </li>
          <?php endif; // app('laratrust')->hasRole ?>
          <?php if (app('laratrust')->hasRole('admin')) : ?>
          <li class="nav-item <?php echo $__env->yieldContent('menu-master'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('master'); ?>">
              <i class="nav-icon fas fa-copy"></i>
              <p>
              Master Data
              <i class="fas fa-angle-left right"></i>
              </p>
          </a>
          <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('kelompok')); ?>" class="nav-link <?php echo $__env->yieldContent('kelompok'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Kelompok Pelajaran</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('jurusan')); ?>" class="nav-link <?php echo $__env->yieldContent('jurusan'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Jurusan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('semester')); ?>" class="nav-link <?php echo $__env->yieldContent('semester'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Semester</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('ekstrakurikuler')); ?>" class="nav-link <?php echo $__env->yieldContent('ekstrakurikuler'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Ekstrakurikuler</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('karakter')); ?>" class="nav-link <?php echo $__env->yieldContent('karakter'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Karakter</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('pelajaran')); ?>" class="nav-link <?php echo $__env->yieldContent('pelajaran'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Pelajaran</p>
                </a>
              </li>
          </ul>
          </li>
          <?php endif; // app('laratrust')->hasRole ?>
          <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
              Logout
              </p>
          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
          </form>
          </li>
      </ul>
      </nav>
      <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH /home/u1686239/public_html/demorapor/resources/views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>