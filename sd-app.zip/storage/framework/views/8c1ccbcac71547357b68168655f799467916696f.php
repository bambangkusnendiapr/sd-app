<table>
    <thead>
    <tr>
        <th>no</th>
        <th>nama</th>
        <th>email</th>
        <th>password</th>
    </tr>
    </thead>
</table><?php /**PATH C:\laragon\www\e-rapor\resources\views/exports/guru.blade.php ENDPATH**/ ?>