<table>
    <thead>
    <tr>
        <th>no</th>
        <th>kode</th>
        <th>nama</th>
        <th>email</th>
        <th>password</th>
    </tr>
    </thead>
</table><?php /**PATH /home/u1686239/public_html/demorapor/resources/views/exports/guru.blade.php ENDPATH**/ ?>