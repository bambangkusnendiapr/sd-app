<table>
    <thead>
    <tr>
        <th>no</th>
        <th>nama_ortu</th>
        <th>email_ortu</th>
        <th>password_ortu</th>
        <th>nama_siswa</th>
        <th>email_siswa</th>
        <th>password_siswa</th>
        <th>kelas</th>
        <th>id_jurusan</th>
    </tr>
    </thead>
</table><?php /**PATH C:\laragon\www\e-rapor\resources\views/exports/siswa.blade.php ENDPATH**/ ?>