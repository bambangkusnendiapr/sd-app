<?php $__env->startSection('title', 'Penilaian'); ?>

<?php $__env->startSection('sidebar', 'sidebar-collapse'); ?>

<?php $__env->startSection('nilai', 'active'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'layouts.admin.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  
  <div>
  
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Penilaian</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item active">Penilaian</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
    
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <form>
                <div class="card-body">
                  <div class="row">
  
                    <div class="col-md-3">
                      <div class="form-group">
                        <select name="pilihKelas" required class="form-control">
                          <option value="">Pilih Kelas</option>
                          <option <?php echo e(request('pilihKelas') == 'X' ? 'selected':''); ?> value="X">X</option>
                          <option <?php echo e(request('pilihKelas') == 'XI' ? 'selected':''); ?> value="XI">XI</option>
                          <option <?php echo e(request('pilihKelas') == 'XII' ? 'selected':''); ?> value="XII">XII</option>
                        </select>
                      </div>
                    </div>
  
                    <div class="col-md-3">
                      <div class="form-group">
                        <select name="pilihJurusan" required class="form-control">
                          <option value="">Pilih Jurusan</option>
                          <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(request('pilihJurusan') == $data->id ? 'selected':''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
  
                    <div class="col-md-3">
                      <div class="form-group">
                        <select name="pilihSemester" required class="form-control">
                          <option value="">Pilih Semester</option>
                          <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(request('pilihSemester') == $data->id ? 'selected':''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
  
                    <div class="col-md-3">
                      <div class="form-group">
                        <select name="pilihPelajaran" required class="form-control">
                          <option value="">Pilih Pelajaran</option>
                          <?php $__currentLoopData = $pelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(request('pilihPelajaran') == $data->id ? 'selected':''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
  
                  </div>
                  <div class="container">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-file-signature"></i> Beri Nilai</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card -->

            <?php if(request('pilihKelas') && request('pilihJurusan') && request('pilihSemester') && request('pilihPelajaran') && $nilai != null && $nilai != 'kosong'): ?>
            <div class="card">
              <div class="card-header">
                <form action="<?php echo e(route('nilai.export')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="pilihKelas" value="<?php echo e(request('pilihKelas')); ?>">
                  <input type="hidden" name="pilihJurusan" value="<?php echo e(request('pilihJurusan')); ?>">
                  <input type="hidden" name="pilihSemester" value="<?php echo e(request('pilihSemester')); ?>">
                  <input type="hidden" name="pilihPelajaran" value="<?php echo e(request('pilihPelajaran')); ?>">
                  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fas fa-file-upload"></i> Upload File</button>
                  <button type="submit" class="btn btn-success"><i class="fas fa-file-download"></i> Download Format Nilai</button>
                </form>
              </div>
              <form action="<?php echo e(route('nilai.update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-2 col-form-label">Ketuntasan Belajar (KB)</label>
                    <div class="col-6">
                      <input type="number" name="kb" required class="form-control" id="inputEmail3" value="<?php echo e($kb); ?>">
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Nama</th>
                          <th scope="col">Pengetahuan</th>
                          <th scope="col">Keterampilan</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                        <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($data->rapor->siswa->user->name); ?></td>
                            <td>
                              <input type="hidden" name="id[]" required class="form-control" value="<?php echo e($data->id); ?>">
                              <input type="number" name="pengetahuan[]" required class="form-control" value="<?php echo e($data->pengetahuan_nilai); ?>">
                            </td>
                            <td>
                              <input type="number" name="keterampilan[]" required class="form-control" value="<?php echo e($data->keterampilan_nilai); ?>">
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="card-footer">
                  <div class="container">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-paper-plane"></i> Simpan Nilai</button>
                  </div>
                </div>
              </form>
            </div>
            <?php elseif($nilai == 'kosong'): ?>
              <h5 class="text-secondary text-center">Rapor belum dibuat. silahkan hubungi wali kelas bersangkutan</h5>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>

    <div class="modal fade" id="modal-default">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-success">
            <h4 class="modal-title">Upload File</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(route('nilai.import')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
              <div class="form-group">
                <div class="input-group">
                  <div class="custom-file">
                    <input type="file" name="file" required class="custom-file-input <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputFile">
                    <label class="custom-file-label" for="exampleInputFile">Pilih file</label>
                  </div>                
                </div>
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success">Upload</button>
            </div>
          </form>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
  
  </div>

  <?php $__env->startPush('style'); ?>
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
  <?php $__env->stopPush(); ?>

  <?php $__env->startPush('script'); ?>
  <!-- SweetAlert2 -->
  <script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
  <!-- Sweet alert real rashid -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
  <!-- bs-custom-file-input -->
  <script src="<?php echo e(asset('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
  <script>
    $(function () {

      <?php if(session()->has('success')): ?>
        Swal.fire({
            "title":"Sukses!",
            "text":"Nilai Berhasil Disimpan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });
      <?php endif; ?>

    });
  </script>
  <script>
    $(function () {
      bsCustomFileInput.init();
    });

    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      $('#modal-default').modal('show');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </script>
  <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/u1686239/public_html/demorapor/resources/views/nilai/index.blade.php ENDPATH**/ ?>