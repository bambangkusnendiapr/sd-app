<?php $__env->startSection('title', 'Penilaian'); ?>

<?php $__env->startSection('sidebar', 'sidebar-collapse'); ?>

<?php $__env->startSection('nilai', 'active'); ?>

<div>

  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Penilaian</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Admin</a></li>
            <li class="breadcrumb-item active">Penilaian</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  
  <!-- Main content -->
  <section class="content">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-body">
              <div class="row">

                <div class="col-md-3">
                  <div class="form-group">
                    <select wire:model="pilihKelas" class="form-control">
                      <option value="">Pilih Kelas</option>
                      <option value="X">X</option>
                      <option value="XI">XI</option>
                      <option value="XII">XII</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <select wire:model="pilihJurusan" class="form-control">
                      <option value="">Pilih Jurusan</option>
                      <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <select wire:model="pilihSemester" class="form-control">
                      <option value="">Pilih Semester</option>
                      <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <select wire:model="pilihPelajaran" class="form-control">
                      <option value="">Pilih Pelajaran</option>
                      <?php $__currentLoopData = $pelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <?php if($nilai != null && $nilai != 'kosong'): ?>
            <div class="card">
              <div class="card-header">
                <div class="form-group row">
                  <label for="inputEmail3" class="col-2 col-form-label">Ketuntasan Belajar (KB)</label>
                  <div class="col-6">
                    <input type="number" required class="form-control" id="inputEmail3" value="<?php echo e($kb); ?>">
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Pengetahuan</th>
                        <th scope="col">Keterampilan</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                      <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td scope="row"><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($data->rapor->siswa->user->name); ?></td>
                          <td>
                            <input wire:model="idNilai.<?php echo e($data->id); ?>" type="number" required class="form-control" value="<?php echo e($data->id); ?>">
                            <input wire:model="pengetahuan.<?php echo e($data->id); ?>" type="number" required class="form-control" value="<?php echo e($data->pengetahuan_nilai); ?>">
                          </td>
                          <td>
                            <input type="number" required class="form-control" value="<?php echo e($data->keterampilan_nilai); ?>">
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          <?php elseif($nilai == 'kosong'): ?>
            <h5 class="text-secondary text-center">Rapor belum dibuat. Silahkan hubungi wali kelas bersangkutan</h5>
          <?php endif; ?>

        </div>
      </div>
    </div>
  </section>

</div>

<?php $__env->startPush('style'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- Sweet alert real rashid -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
  $(function () {

    window.addEventListener('show-form', event => {
        $('#form').modal('show');
    });

    window.addEventListener('hide-form', event => {
        $('#form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('catatan-akademik', event => {

        Swal.fire({
            "title":"Sukses!",
            "text":"Catatan Akademik Berhasil Diupdate",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('eskul-show-form', event => {
        $('#eskul-form').modal('show');
    });

    window.addEventListener('hide-eskul-form', event => {
        $('#eskul-form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('ketidakhadiran', event => {

      Swal.fire({
          "title":"Sukses!",
          "text":"Ketidakhadiran Berhasil Diupdate",
          "position":"middle-center",
          "timer":2000,
          "width":"32rem",
          "heightAuto":true,
          "padding":"1.25rem",
          "showConfirmButton":false,
          "showCloseButton":false,
          "icon":"success"
      });

    });

    window.addEventListener('rapor-karakter-show-form', event => {
        $('#rapor-karakter-form').modal('show');
    });

    window.addEventListener('hide-rapor-karakter-form', event => {
        $('#rapor-karakter-form').modal('hide');

        Swal.fire({
            "title":"Sukses!",
            "text":"Data Berhasil Ditambahkan",
            "position":"middle-center",
            "timer":2000,
            "width":"32rem",
            "heightAuto":true,
            "padding":"1.25rem",
            "showConfirmButton":false,
            "showCloseButton":false,
            "icon":"success"
        });

    });

    window.addEventListener('catatan-karakter', event => {

      Swal.fire({
          "title":"Sukses!",
          "text":"Catatan Perkembangan Karakter Berhasil Diupdate",
          "position":"middle-center",
          "timer":2000,
          "width":"32rem",
          "heightAuto":true,
          "padding":"1.25rem",
          "showConfirmButton":false,
          "showCloseButton":false,
          "icon":"success"
      });

    });

  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

  })
  
</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\e-rapor\resources\views/livewire/nilai-data.blade.php ENDPATH**/ ?>