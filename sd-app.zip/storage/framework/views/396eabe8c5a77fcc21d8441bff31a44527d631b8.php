<table>
    <thead>
    <tr>
        <th>tanggal</th>
        <th>siswa_id</th>
        <th>jilid</th>
        <th>halaman</th>
        <th>murajaah</th>
        <th>ziyadah</th>
        <th>nilai</th>
    </tr>
    </thead>
</table><?php /**PATH C:\laragon\www\sd-app\resources\views/admin/exports/tahsin.blade.php ENDPATH**/ ?>