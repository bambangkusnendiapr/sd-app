<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="#" class="brand-link">
      <img src="https://laravel.com/img/logomark.min.svg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Template</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
          <img src="<?php echo e(asset('admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
          <a href="<?php echo e(route('profile')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?>

            <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge badge-success"><?php echo e($role->display_name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </a>
      </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
              with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                Dashboard
                </p>
            </a>
          </li>
          <?php if (app('laratrust')->hasRole('admin')) : ?>
          <li class="nav-item <?php echo $__env->yieldContent('menu-master'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('master'); ?>">
              <i class="nav-icon fas fa-copy"></i>
              <p>
              Master Data
              <i class="fas fa-angle-left right"></i>
              </p>
          </a>
          <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('users')); ?>" class="nav-link <?php echo $__env->yieldContent('users'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('roles')); ?>" class="nav-link <?php echo $__env->yieldContent('roles'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Role</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('permissions')); ?>" class="nav-link <?php echo $__env->yieldContent('permissions'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Permission</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('menus')); ?>" class="nav-link <?php echo $__env->yieldContent('menus'); ?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Menu</p>
                </a>
              </li>
          </ul>
          </li>
          <?php endif; // app('laratrust')->hasRole ?>
          <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
              Logout
              </p>
          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
          </form>
          </li>
      </ul>
      </nav>
      <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH C:\laragon\www\template\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>